# learn python
## about app
this is a simple app made for beginners to learn python basics
i learned python from various youtube channels and app
but most of apps are works with pc
so whats about mobile
this is the reason i made this app
just enjoy app
`no premium` because education is not business
## about app creater
name : `siva rama raju`
i am a student completed intermediate
app created at 27-05-2024
## follow me on
`instagram` :[sla_codeing](https://www.instagram.com/sla_codeing?igsh=YjZxOXNpNDB1aW92)
`youtube` :[sla codeing](https://youtube.com/@slacodeing?si=CvJMnxT8coL_XTs2)
`telegram` :[sla codeing](https://t.me/sla_codeing?fbclid=PAZXh0bgNhZW0CMTEAAaZp_5TeRCuPfsMzCz4t3X1Zkl0HF8airuCtd-0fUPugGWxyxmZPldQqfEw_aem_2c-5PBNs848mLCFDLJotKw)